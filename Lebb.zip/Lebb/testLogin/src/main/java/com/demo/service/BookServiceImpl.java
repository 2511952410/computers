package com.demo.service;

import com.demo.dao.impl.BookDao;
import com.demo.domain.Book;
import com.demo.domain.BookType;
import com.demo.service.impl.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 16:29:05
 * @packageName com.demo.service
 * @className BookServiceImpl
 * @describe TODO
 */
@Transactional
@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookDao bookDao;
    @Override
    public List<Book> selectAll(int pageInteger, int limitInteger) {

        int pageIndex = (pageInteger-1) * limitInteger;
        int pageSize = limitInteger;

       return bookDao.selectAll(pageIndex, pageSize);

    }

    @Override
    public List<BookType> getBookType() {
        return bookDao.getBookType();
    }

    @Override
    public List<Book> getBookById(Book book) {
        return bookDao.getBookById(book);
    }

    @Override
    public int deleteBookByID(String id) {
        return bookDao.deleteBookByID(id);
    }

    @Override
    public int getCount() {
        return this.bookDao.getCount();
    }

}
