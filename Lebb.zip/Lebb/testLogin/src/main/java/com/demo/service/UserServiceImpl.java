package com.demo.service;

import com.demo.dao.impl.UserDao;
import com.demo.domain.Address;
import com.demo.domain.User;
import com.demo.service.impl.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月18日 10:10:00
 * @packageName com.demo.service
 * @className UserServiceImpl
 * @describe TODO
 */
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;
    @Override
    public List<User> getUser() {
        return userDao.getUser();
    }

    @Override
    public List<Address> getAddress() {
        return userDao.getAddress();
    }

    @Override
    public int addUser(User user) {
        return userDao.addUser(user);
    }

    @Override
    public int getCount() {
        return this.userDao.getCount();
    }

    @Override
    public List<User> selectAll(int pageInteger, int limitInteger) {
        int pageIndex = (pageInteger-1) * limitInteger;
        int pageSize = limitInteger;

        return userDao.selectAll(pageIndex, pageSize);
    }

    @Override
    public int getAdCount() {
        return this.userDao.getAdCount();
    }

    @Override
    public List<User> selectAdAll(int pageInteger, int limitInteger) {
        int pageIndex = (pageInteger-1) * limitInteger;
        int pageSize = limitInteger;

        return userDao.selectAdAll(pageIndex, pageSize);
    }

    @Override
    public String deleteUserByUserName(String username) {
        return userDao.deleteUserByUserName(username);
    }
}
