package com.demo.controller;

import com.alibaba.fastjson.JSON;
import com.demo.domain.Address;
import com.demo.domain.Book;
import com.demo.domain.BookType;
import com.demo.service.impl.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 14:26:55
 * @packageName com.demo.controller
 * @className BookController
 * @describe TODO
 */
@RestController
@RequestMapping("/book")
public class BookController {
    @Autowired
    private BookService bookService;
    @RequestMapping("/getCount")
    @ResponseBody
    public String getCount(){
        int count = bookService.getCount();
        String data = "{\"count\":"+count+"}";
        return data;
    }
    @RequestMapping("/findAll")
    @ResponseBody
    public   Map<String,List<Book>> findAll(int page,int limit){
        List<Book> bookList = bookService.selectAll(page,limit);
        Map<String,List<Book>> map = new HashMap<String, List<Book>>();
        map.put("data",bookList);
        return map;

    }



    @RequestMapping("/delete")
    @ResponseBody
    public int deleteBook(@RequestParam("id") String id){
        System.out.println("删除操作");
        return bookService.deleteBookByID(id);
    }

    @RequestMapping("/booktype")
    @ResponseBody
    public void listType(HttpServletResponse response) {
        List<BookType> bookTypeList = bookService.getBookType();
        List<String> listsStrings = new ArrayList<String>();
        for(BookType bookType: bookTypeList) {
            listsStrings.add(bookType.getClass_name());
        }
        String json = JSON.toJSONString(listsStrings);
        response.setCharacterEncoding("UTF-8");
        try {
            response.getWriter().print(json);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
