package com.demo.controller;

import com.alibaba.fastjson.JSON;
import com.demo.domain.Address;
import com.demo.domain.User;
import com.demo.service.impl.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月18日 10:12:35
 * @packageName com.demo.controller
 * @className LoginController
 * @describe TODO
 */
@RestController
@RequestMapping("/Login")
public class LoginController {
    @Autowired
    private UserService userService;
    static Logger logger = Logger.getLogger(LoginController.class.getName());
    public static String username = "";
    public static String name = "";
    public static User currnUser;

    @RequestMapping("/loginto")
    public void LointTo(HttpServletResponse response, @RequestParam(value = "loginUsername") String username,
                        @RequestParam(value = "loginPassword") String password, @RequestParam(value = "loginType") int loginType,
                        HttpSession session) {
        List<Integer> retjson = new ArrayList<Integer>();
        List<User> users = userService.getUser();
        try {
            Optional<User> getLisUser = users.stream().filter(item -> item.username.equals(username)).findFirst();// 返回查找到的第一个元素
            if (getLisUser.isPresent()) {
                User user = getLisUser.get();
                if (user.getPassword().equals(password) && user.getType() == loginType) {
                    this.username = username;
                    this.name = user.getName();
                    this.currnUser = user;
                    logger.info("登录人员:" + JSON.toJSONString(user));
                    retjson.add(200);
                    session.setAttribute("username", username);
                    session.setAttribute("name", user.getName());
                    session.setAttribute("user", user);
                    session.setAttribute("intal", user.getIntal());
                    session.setAttribute("user2", JSON.toJSONString(user));
                    retjson.add(loginType);
                } else {
                    retjson.add(300);
                    retjson.add(loginType);
                }
            } else {
                logger.info("登录错误");
                retjson.add(500);
            }
        } catch (Exception e) {
            logger.info("登录错误2");
            retjson.add(500);
        }
        try {
            response.getWriter().print(retjson);
        } catch (IOException e) {

            logger.info("错误");
        }
    }
    @RequestMapping("/address")
    public void listOption(HttpServletResponse response) {
        List<Address> lisoptList = userService.getAddress();
        List<String> listsStrings = new ArrayList<String>();
        for(Address address: lisoptList) {
            listsStrings.add(address.getAddress());
        }
        String json = JSON.toJSONString(listsStrings);
        response.setCharacterEncoding("UTF-8");
        try {
            response.getWriter().print(json);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    @RequestMapping("/adduser.do")
    public void AddUserDo(HttpServletResponse response,
                          @RequestParam(value = "registerUsername") String username,
                          @RequestParam(value = "registerNname") String name, @RequestParam(value = "registerPhone") String phone,
                          @RequestParam(value = "registerAddress") String address, @RequestParam(value = "selectType") int sex,
                          @RequestParam(value = "registerPassword") String password) {
        logger.info(username + ":" + name + ":" + phone + ":" + sex + ":" + password + ":" + address);
        List<Integer> retjson = new ArrayList<Integer>();
        User user = new User(username,name,phone,address,sex,password,0,1);
        int count = userService.addUser(user);
        if(count > 0) {
            retjson.add(200);
        }else {
            retjson.add(500);
        }
        try {
            response.getWriter().print(JSON.toJSONString(retjson));
        } catch (IOException e) {

            e.printStackTrace();
        }
    }
}

