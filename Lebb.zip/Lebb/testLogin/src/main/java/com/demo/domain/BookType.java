package com.demo.domain;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 20:44:32
 * @packageName com.demo.domain
 * @className BookTypeDao
 * @describe TODO
 */
public class BookType {
    @Override
    public String toString() {
        return "BookType{" +
                "class_id=" + class_id +
                ", class_name='" + class_name + '\'' +
                '}';
    }

    public Integer getClass_id() {
        return class_id;
    }

    public void setClass_id(Integer class_id) {
        this.class_id = class_id;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    private  Integer class_id;
    private  String class_name;


}
