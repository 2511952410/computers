package com.demo.dao.impl;

import com.demo.domain.Address;
import com.demo.domain.Book;
import com.demo.domain.BookType;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 16:59:27
 * @packageName com.demo.dao.impl
 * @className BookDao
 * @describe TODO
 */
public interface BookDao {
    @Select("select * from book limit #{param1},#{param2}")
    List<Book> selectAll(int pageIndex, int pageSize);
    @Select(" select count(*) from book")
    public int getCount();
@Select("select class_name from booktype")
public List<BookType> getBookType();
    @Select("select * from book where bookid=#{bookid}")
    List<Book> getBookById(Book book);
    @Delete("delete from book where bookid=#{bookid}")
    int deleteBookByID(String id);
}
