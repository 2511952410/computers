package com.demo.dao.impl;

import com.demo.domain.Address;
import com.demo.domain.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月18日 10:05:53
 * @packageName com.demo.dao.impl
 * @className UserDao
 * @describe TODO
 */
public interface UserDao {
    @Select("select * from user")
    public List<User> getUser();
    @Select("select * from address")
    public List<Address> getAddress();
    @Insert("insert into user(username,name,phone,address,sex,password) values (#{username},#{name},#{phone},#{address},#{sex},#{password})")
    public int addUser(User user);
@Select("select * from address where address like #{address}")
    public List<Address> getUserAdress(String adderess);

    @Select("select * from user where type=0 limit #{param1},#{param2}")
    List<User> selectAdAll(int pageIndex, int pageSize);
    @Select(" select count(*) from user where type=0")
    public int getAdCount();
    @Select("select * from user  where type=1 limit #{param1},#{param2} ")
    List<User> selectAll(int pageIndex, int pageSize);
    @Select(" select count(*) from user where type=1")
    public int getCount();

    @Delete("delete from user where username=#{username}")
    String deleteUserByUserName(String username);
}
