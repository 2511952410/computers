$().ready(function() {
    load();
});
layui.use(['layer'], function() {
    var layer = layui.layer;
})
$(function() {
    // 注册事件
    $('#loginRegister').click(function() {
        register();
    });
});
// 注册流程
function register() {
    layer.open({
        type: '1',
        content: $('.registerPage'),
        title: '注册',
        area: ['430px', '400px'],
        btn: ['注册', '重置', '取消'],
        closeBtn: 0,
        btn1: function(index, layero) {
            //注册回调
            layer.close(index);
            var registerUsername = $('#registerUsername').val();
            var registerName = $('#registerNname').val();
            var registerPhone = $('#registerPhone').val();
            var registerAddress = $('#registerAddress option:selected').text();
            var selectType = $('#roleSelectType').val();
            var registerPassword = $('#registerPassword').val();
            var registerWellPassword = $('#registerWellPassword').val();
            if (registerUsername == "" || registerName == "" || registerPassword == "" || registerWellPassword == "" || registerAddress == "") {
                alert("必填信息不能为空,注册失败！");
                $('.registerPage').hide();
                return;
            }
            if (registerPassword != registerWellPassword) {
                alert("两次密码不一致,注册失败！");
                $('.registerPage').hide();
                return;
            }
            var registerLoadIndex = layer.load(2);
            $.ajax({
                type: 'post',
                url: 'http://localhost:8080/Login/adduser.do',
                dataType: 'html',
                data: {
                    'registerUsername': registerUsername,
                    'registerNname': registerName,
                    'registerPhone': registerPhone,
                    'registerAddress': registerAddress,
                    'selectType': selectType,
                    'registerPassword': registerPassword
                },
                success: function(data) {
                    layer.close(registerLoadIndex);
                    var jsonData = JSON.parse(data);
                    if (jsonData[0] == 200) {
                        $('.registerPage').hide();
                        layer.alert("注册成功!");
                    } else {
                        $('.registerPage').hide();
                        layer.alert("用户已存在，请重新注册!");
                        return false;
                    }
                },
                error: function() {
                    $('.registerPage').hide();
                    layer.close(registerLoadIndex);
                    layer.alert("请求超时，用户名已注册");

                }
            });
        },
        btn2: function(index, layero) {
            //重置回调
            $('#registerUsername').val("");
            $('#registerPassword').val("");
            $('#registerWellPassword').val("");
            $('.registerPage').hide();
            return false;
        },
        btn3: function(index, layero) {
            //取消回调
            $('.registerPage').hide();
        }
    })
}
function load() {
    $.ajax({
        type: 'post',
        url: 'http://localhost:8080/Login/address',
        dataType: 'html',
        data: {},
        success: function(data) {
            var jsonData = JSON.parse(data);
            var parknames = [];
            for (var i = 0; i < jsonData.length; i++) {
                parknames.push('<option value="' + i + '">' + jsonData[i] + '</option>');
            }
            //parknames.push('<option value="'+jsonData.length+'">'+暂无+'</option>');
            $("#registerAddress").html(parknames.join(' '));
        },
        error: function() {
            alert("获取失败");
        }
    });
}