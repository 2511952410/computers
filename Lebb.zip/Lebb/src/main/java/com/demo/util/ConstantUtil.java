package com.demo.util;

import com.google.gson.Gson;

import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 23:41:41
 * @packageName com.demo.util
 * @className ConstantUtil
 * @describe TODO
 */
public class ConstantUtil {
    public final static String PREFIX = "{\"code\":0,\"msg\":\"\",\"count\":";
    public final static String DATA = ",\"data\":";
    public final static String SUFFIX = "}";

    /**
     * 分页时传入总的记录数和当前页对象的泛型集合
     * @param list 当前页对象的泛型集合
     * @param count 总的记录数
     * @return 当前页数据的json字符串
     */
    public static String getLayerJson(List<?> list, int count) {
        Gson gson = new Gson();
        return PREFIX + count + DATA + gson.toJson(list) + SUFFIX;
    }



}
