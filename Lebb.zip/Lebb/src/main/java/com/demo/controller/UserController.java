package com.demo.controller;

import com.demo.domain.Book;
import com.demo.domain.User;
import com.demo.service.impl.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 14:26:30
 * @packageName com.demo.controller
 * @className UserController
 * @describe TODO
 */
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping("/selectAdmin")
    @ResponseBody
    public String getAdminInfo() throws JsonProcessingException {

        List<User> adminList = userService.selectAdmin();
        ObjectMapper objectMapper = new ObjectMapper();

        String s = "{\n" +
                "  \"code\": 0,\n" +
                "  \"msg\": \"\",\n" +
                "  \"count\": 1000,\n" +
                "  \"data\": [";
        for (User user : adminList) {
            s += objectMapper.writeValueAsString(user);
            s += ",";
        }
        s = s.substring(0, s.length() -1);
        s += " ]\n" +
                "}";

        System.out.println(s);
        return s;
    }

    @RequestMapping("/selectUser")
    @ResponseBody
    public String getUserInfo() throws JsonProcessingException {

        List<User> adminList = userService.selectUser();
        ObjectMapper objectMapper = new ObjectMapper();

        String s = "{\n" +
                "  \"code\": 0,\n" +
                "  \"msg\": \"\",\n" +
                "  \"count\": 1000,\n" +
                "  \"data\": [";
        for (User user : adminList) {
            s += objectMapper.writeValueAsString(user);
            s += ",";
        }
        s = s.substring(0, s.length() -1);
        s += " ]\n" +
                "}";

        System.out.println(s);
        return s;
    }
    @RequestMapping("/getCount")
    @ResponseBody
    public String getCount(){
        int count = userService.getCount();
        String data = "{\"count\":"+count+"}";
        return data;
    }
    @RequestMapping("/findAll")
    @ResponseBody
    public Map<String,List<User>> findAll(int page, int limit){
        List<User> userList = userService.selectAll(page,limit);
        Map<String,List<User>> map = new HashMap<String, List<User>>();
        map.put("data",userList);
        return map;

    }

    @RequestMapping("/getAdCount")
    @ResponseBody
    public String getAdCount(){
        int count = userService.getAdCount();
        String data = "{\"count\":"+count+"}";
        return data;
    }
    @RequestMapping("/findAdAll")
    @ResponseBody
    public Map<String,List<User>> findAdAll(int page, int limit){
        List<User> userList = userService.selectAdAll(page,limit);
        Map<String,List<User>> map = new HashMap<String, List<User>>();
        map.put("data",userList);
        return map;

    }
}
