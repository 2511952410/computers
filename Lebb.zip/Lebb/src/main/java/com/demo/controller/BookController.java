package com.demo.controller;

import com.demo.config.Result;
import com.demo.domain.Book;
import com.demo.domain.BookType;
import com.demo.service.impl.BookService;
import com.demo.util.ConstantUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 14:26:55
 * @packageName com.demo.controller
 * @className BookController
 * @describe TODO
 */
@RestController
@RequestMapping("/book")
public class BookController {
    @Autowired
    private BookService bookService;
    @RequestMapping("/getCount")
    @ResponseBody
    public String getCount(){
        int count = bookService.getCount();
        String data = "{\"count\":"+count+"}";
        return data;
    }
    @RequestMapping("/findAll")
    @ResponseBody
    public   Map<String,List<Book>> findAll(int page,int limit){
        List<Book> bookList = bookService.selectAll(page,limit);
        Map<String,List<Book>> map = new HashMap<String, List<Book>>();
        map.put("data",bookList);
        return map;

    }





}
