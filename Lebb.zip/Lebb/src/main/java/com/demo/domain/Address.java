package com.demo.domain;

/**
 * @author ��ͨ
 * @version 1.0.0
 * @date 2022��09��17�� 11:20:26
 * @packageName com.demo.dao.impl
 * @className UserDao
 * @describe TODO
 */
public class Address {
	public String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Address(String address) {
		super();
		this.address = address;
	}

	@Override
	public String toString() {
		return "Address [address=" + address + "]";
	}
}
