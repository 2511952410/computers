package com.demo.domain;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 11:27:44
 * @packageName com.demo.domain
 * @className User
 * @describe TODO
 */
public class User {
    public String username;
    public String name;
    public String phone;
    public String address;
    public int sex;
    public String password;
    public int intal;
    public int type;
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public int getSex() {
        return sex;
    }
    public void setSex(int sex) {
        this.sex = sex;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public int getIntal() {
        return intal;
    }
    public void setIntal(int intal) {
        this.intal = intal;
    }
    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }
    public User(String username, String name, String phone, String address, int sex, String password, int intal,
                int type) {
        super();
        this.username = username;
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.sex = sex;
        this.password = password;
        this.intal = intal;
        this.type = type;
    }
    @Override
    public String toString() {
        return "User [username=" + username + ", name=" + name + ", phone=" + phone + ", address=" + address + ", sex="
                + sex + ", password=" + password + ", intal=" + intal + ", type=" + type + "]";
    }
}
