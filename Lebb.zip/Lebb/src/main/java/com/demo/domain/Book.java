package com.demo.domain;

import com.fasterxml.jackson.annotation.JsonFormat;


import java.util.Date;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 16:23:56
 * @packageName com.demo.domain
 * @className Book
 * @describe TODO
 */
public class Book {
    private Integer bookid;
    private String name;
    private String author;
    private String publish;

    public Book() {
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookid=" + bookid +
                ", name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", publish='" + publish + '\'' +
                ", ISBN='" + ISBN + '\'' +
                ", introduction='" + introduction + '\'' +
                ", price=" + price +
                ", pub_date=" + pub_date +
                ", classid=" + classid +
                ", number=" + number +
                '}';
    }

    private String ISBN;

    public Integer getBookid() {
        return bookid;
    }

    public void setBookid(Integer bookid) {
        this.bookid = bookid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublish() {
        return publish;
    }

    public void setPublish(String publish) {
        this.publish = publish;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Date getPub_date() {
        return pub_date;
    }

    public void setPub_date(Date pub_date) {
        this.pub_date = pub_date;
    }

    public int getClassid() {
        return classid;
    }

    public void setClassid(int classid) {
        this.classid = classid;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    private String introduction;

    private Double price;
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date pub_date;
    private int classid;
    private int number;
}
