package com.demo.domain;

import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 20:44:32
 * @packageName com.demo.domain
 * @className BookTypeDao
 * @describe TODO
 */
public class BookType {
    private  Integer id;
    private  String class_id;

    @Override
    public String toString() {
        return "BookTypeDao{" +
                "id=" + id +
                ", class_id='" + class_id + '\'' +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClass_id() {
        return class_id;
    }

    public void setClass_id(String class_id) {
        this.class_id = class_id;
    }

}
