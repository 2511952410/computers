package com.demo.dao.impl;

import com.demo.domain.Book;
import com.demo.domain.BookType;
import com.demo.domain.User;
import org.apache.ibatis.annotations.Select;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 16:59:27
 * @packageName com.demo.dao.impl
 * @className BookDao
 * @describe TODO
 */
public interface BookDao {
    @Select("select * from book limit #{param1},#{param2}")
    List<Book> selectAll(int pageIndex,int pageSize);
    @Select(" select count(*) from book")
    public int getCount();



}
