package com.demo.service.impl;

import com.demo.config.Result;
import com.demo.domain.Book;
import com.demo.domain.BookType;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.Results;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 16:28:48
 * @packageName com.demo.service.impl
 * @className BookService
 * @describe TODO
 */
public interface BookService {
    public int getCount();
    List<Book> selectAll(int pageInteger,int limitInteger);


}
