package com.demo.service;

import com.demo.dao.impl.UserDao;
import com.demo.domain.Address;
import com.demo.domain.User;
import com.demo.service.impl.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 11:31:52
 * @packageName com.demo.service
 * @className UserServiceImpl
 * @describe TODO
 */
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;


    @Override
    public List<User> getUser() {
        return null;
    }

    @Override
    public int addUser(User user) {
        return userDao.addUser(user);
    }

    @Override
    public List<Address> getAddress() {

        return userDao.getAddress();
    }

    @Override
    public User queryUser(String username) {
        return userDao.queryUser(username);
    }

    @Override
    public List<User> selectUser() {
        List<User>list= userDao.selectUser();
        return list;
    }

    @Override
    public List<User> selectAdmin() {
        List<User>list= userDao.selectAdmin();
        return  list;
    }

    @Override
    public int getCount() {
        return this.userDao.getCount();
    }

    @Override
    public List<User> selectAll(int pageInteger, int limitInteger) {
        int pageIndex = (pageInteger-1) * limitInteger;
        int pageSize = limitInteger;

        return userDao.selectAll(pageIndex, pageSize);
    }

    @Override
    public int getAdCount() {
        return this.userDao.getAdCount();
    }

    @Override
    public List<User> selectAdAll(int pageInteger, int limitInteger) {
        int pageIndex = (pageInteger-1) * limitInteger;
        int pageSize = limitInteger;

        return userDao.selectAdAll(pageIndex, pageSize);
    }


}