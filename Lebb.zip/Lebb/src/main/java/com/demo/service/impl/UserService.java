package com.demo.service.impl;

import com.demo.domain.Address;
import com.demo.domain.Book;
import com.demo.domain.User;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月17日 11:31:40
 * @packageName com.demo.service.impl
 * @className UserService
 * @describe TODO
 */
public interface UserService {
    public List<User> getUser();
    public int addUser(User user);
    public List<Address> getAddress();
    public User queryUser(String username);
    public List<User> selectUser();
    public List<User> selectAdmin();
    public int getCount();
    List<User> selectAll(int pageInteger,int limitInteger);
    public int getAdCount();
    List<User> selectAdAll(int pageInteger,int limitInteger);
}
