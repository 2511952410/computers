package com.demo.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月07日 09:36:53
 * @packageName PACKAGE_NAME
 * @className SpringMvcConfig
 * @describe TODO
 */
@Configuration
@ComponentScan({"com.demo.controller","com.demo.config"})
@EnableWebMvc
public class SpringMvcConfig {
}
