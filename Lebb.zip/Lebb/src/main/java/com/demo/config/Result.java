package com.demo.config;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月08日 11:24:14
 * @packageName com.demo.config
 * @className Result
 * @describe TODO
 */
public class Result {
    private Object object;
    private  Integer code;
    private String msg;
public  Result(){

}
    public Result(Object object,Integer code) {
        this.object = object;
        this.code=code;
    }

    public Result(Object object, Integer code, String msg) {
        this.object = object;
        this.code = code;
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "Result{" +
                "object=" + object +
                ", code=" + code +
                ", msg='" + msg + '\'' +
                '}';
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
