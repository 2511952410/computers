package com.demo.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月07日 11:32:14
 * @packageName com.demo.config
 * @className SpringConfig
 * @describe TODO
 */

@Configuration
@ComponentScan({"com.demo"})
@PropertySource("classpath:jdbc.properties")
@Import({JdbcConfig.class,MybatisConfig.class})
public class SpringConfig {
}
