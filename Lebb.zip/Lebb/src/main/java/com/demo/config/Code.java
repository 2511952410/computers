package com.demo.config;

/**
 * @author 刘通
 * @version 1.0.0
 * @date 2022年09月08日 11:27:09
 * @packageName com.demo.config
 * @className Code
 * @describe TODO
 */
public class Code {

    public static final Integer SAVE_OK = 40;
    public static final Integer SAVE_ERR = 41;
    public static final Integer DELETE_OK = 42;
    public static final Integer DELETE_ERR = 43;

    public static final Integer UPDATE_OK = 44;
    public static final Integer UPDATE_ERR = 45;
    public static final Integer GET_OK = 46;
    public static final Integer GET_ERR =47 ;
}
